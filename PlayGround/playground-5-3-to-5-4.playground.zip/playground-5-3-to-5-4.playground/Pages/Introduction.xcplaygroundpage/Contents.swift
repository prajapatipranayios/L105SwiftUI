/*:
# What’s new in Swift

* Created by [Paul Hudson](https://twitter.com/twostraws) – [Hacking with Swift](https://www.hackingwithswift.com)

This playground is designed to showcase new features introduced after Swift 5.3, up to and including Swift 5.4. If you hit problems or have questions, you're welcome to tweet me [@twostraws](https://twitter.com/twostraws) or email <paul@hackingwithswift.com>.


 &nbsp;
## Changes in Swift 5.4
 * [Improved implicit member syntax](Improved%20implicit%20member%20syntax)
 * [Multiple variadic parameters in functions](Multiple%20variadic%20parameters%20in%20functions)
 * [Local functions now support overloading](Local%20functions%20now%20support%20overloading)
 * [Creating variables that call a function of the same name](Creating%20variables%20that%20call%20a%20function%20of%20the%20same%20name)
 * [Result builders](Result%20builders)
 * [Property wrappers are now supported for local variables](Property%20wrappers%20are%20now%20supported%20for%20local%20variables)
 * [Packages can now declare executable targets](Packages%20can%20now%20declare%20executable%20targets)

&nbsp;

[Next >](@next)
*/
/*:
# What’s new in Swift

* Created by [Paul Hudson](https://twitter.com/twostraws) – [Hacking with Swift](https://www.hackingwithswift.com)

This playground is designed to showcase new features introduced after Swift 5.0, up to and including Swift 5.1. If you hit problems or have questions, you're welcome to tweet me [@twostraws](https://twitter.com/twostraws) or email <paul@hackingwithswift.com>.


 &nbsp;
## Changes in Swift 5.1
 * [Improvements to synthesized memberwise initializers](Improvements%20to%20synthesized%20memberwise%20initializers)
 * [Implicit returns from single-expression functions](Implicit%20returns%20from%20single-expression%20functions)
 * [Universal `Self`](Universal%20Self)
 * [Opaque return types](Opaque%20return%20types)
 * [Static and class subscripts](Static%20and%20class%20subscripts)
 * [Warnings for ambiguous `none` cases](Warnings%20for%20ambiguous%20none%20cases)
 * [Matching optional enums against non-optionals](Matching%20optional%20enums%20against%20non-optionals)
 * [Ordered collection diffing](Ordered%20collection%20diffing)
 * [Creating uninitialized arrays](Creating%20uninitialized%20arrays)

&nbsp;

[Next >](@next)
*/